export interface ICustomer{
    customerId :number;
    firstName : string;
    lastName : string;
    mobileNumber : string;
    IAddress : any;
    email : string;
   }