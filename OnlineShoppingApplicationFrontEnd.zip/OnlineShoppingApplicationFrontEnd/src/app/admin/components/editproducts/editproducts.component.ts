import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editproducts',
  templateUrl: './editproducts.component.html',
  styleUrls: ['./editproducts.component.css']
})
export class EditproductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
