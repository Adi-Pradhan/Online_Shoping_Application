export enum IOrderStatus{

    BOOKED,SHIPPED,DELIVERED,DELAYED,CLOSED

}