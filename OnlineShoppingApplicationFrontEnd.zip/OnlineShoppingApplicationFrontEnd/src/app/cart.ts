
export interface ICart{
    cartId:number;
    customerId:number;
   //ICustomer : any;
   //IProducts : any;
  productId:number;
   quantity:number;
   }